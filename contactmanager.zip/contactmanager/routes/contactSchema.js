var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

// contact schema 
var contactSchema   = new Schema({
	firstName: String,
	lastName: String,
	gender: String,
	dob: Date,
	mobile: {type:Number, unique:true},
	email: {type:String, unique:true},
	country: String
});

module.exports = mongoose.model('Contact', contactSchema);