var express = require('express');
var moment = require('moment');
var router = express.Router();
var registerContact = require('../routes/contactSchema');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


//Dashboard
router.get('/dashboard',function(req,res,next){
	res.render('dashboard',{ title: 'Express' });
});

//Charts
router.get('/charts',function(req,res,next){
	res.render('charts',{ title: 'Express' });
});

//Tables
router.get('/register',function(req,res,next){
	res.render('register');
});


//Forms
//inserting data into database
router.post('/register',function(req,res,next){
	//toaster.success('Contact added successfully');
	
	var contact = new registerContact();
	contact.firstName = req.body.firstName;
	contact.lastName = req.body.lastName;
	contact.gender = req.body.gender;
	contact.dob = req.body.dob;
	contact.mobile = req.body.mobile;
	contact.email = req.body.email;
	contact.country = req.body.country;

	console.log(req.body.firstName);
	console.log(req.body.lastName);
	console.log(req.body.gender);
	console.log(req.body.dob);
	console.log(req.body.mobile);
	console.log(req.body.email);
	console.log(req.body.country);

	contact.save(function(err){
		if(err){
			return res.send(err);
		}
		
		res.render('register');
         

	});
});
// router.get('/forms',function(req,res,next){
// 	res.render('forms');
// });
//Getting all the contacts from database
router.get('/allContacts',function(req,res){
	registerContact.find({},function(err,contacts){
		if(err)
			res.send(err);
		res.render('allContacts', { contact: contacts , moment: moment});
	});
	
});

//for searching a single contact
router.get('/searchContact',function(req,res,next){
	
	var re = new RegExp(req.query.firstName, 'i');

	registerContact.find().or([{ 'firstName': { $regex: re }}, { 'lastName': { $regex: re }},{ 'email': { $regex: re }}]).exec(function(err, contacts){
		if(err)
			res.send(err);
		console.log(contacts);
		//res.json(JSON.stringify(contacts));
		res.render('allContacts', {contact: contacts, moment: moment});
	});
	
});


router.get('/deleteContact',function(req, res) {
	
	console.log(req.query.deleteName);
	
    registerContact.remove({'firstName':req.query.deleteName}, function(err, contacts) {
		if (err) 
			return res.send(err);
        res.render('allContacts', { contact: contacts , moment: moment});
	}); 
});

//Bootstrap Elements
router.get('/bootstrapElements',function(req,res,next){
	res.render('bootstrapElements');
});

//Bootstrap Grid
router.get('/bootstrapGrid',function(req,res,next){
	res.render('bootstrapGrid');
});

//Blank
router.get('/blank',function(req,res,next){
	res.render('blank');
});

//RTL Dashboard
router.get('/rtlDashboard',function(req,res,next){
	res.render('rtlDashboard');
});
module.exports = router;

